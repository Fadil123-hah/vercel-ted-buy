package com.dilzx.aicamera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.ScaleGestureDetector
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.ZoomState
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Hdr
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

// ══════════════════════════════════════════════════════
//  THEME COLORS (One UI Inspired)
// ══════════════════════════════════════════════════════

val CameraYellow = Color(0xFFFFD60A)
val CameraWhite = Color(0xFFFFFFFF)
val CameraBlack = Color(0xFF000000)
val CameraGray = Color(0xFF888888)
val CameraOverlayDark = Color(0x88000000)
val CameraOverlayLight = Color(0x33FFFFFF)

// ══════════════════════════════════════════════════════
//  VIEW MODEL
// ══════════════════════════════════════════════════════

class CameraViewModel : ViewModel() {

    private val _isProcessing = MutableLiveData(false)
    val isProcessing: LiveData<Boolean> = _isProcessing

    private val _lastCapturedBitmap = MutableLiveData<Bitmap?>(null)
    val lastCapturedBitmap: LiveData<Bitmap?> = _lastCapturedBitmap

    private val _enhancedBitmap = MutableLiveData<Bitmap?>(null)
    val enhancedBitmap: LiveData<Bitmap?> = _enhancedBitmap

    private val _errorMessage = MutableLiveData<String?>(null)
    val errorMessage: LiveData<String?> = _errorMessage

    private val _selectedMode = MutableLiveData(CameraMode.PHOTO)
    val selectedMode: LiveData<CameraMode> = _selectedMode

    fun setMode(mode: CameraMode) {
        _selectedMode.value = mode
    }

    fun processImage(bitmap: Bitmap) {
        val mode = _selectedMode.value ?: CameraMode.PHOTO
        _lastCapturedBitmap.value = bitmap
        _isProcessing.value = true
        _errorMessage.value = null

        viewModelScope.launch(Dispatchers.IO) {
            when (val result = GeminiApiClient.enhanceImage(bitmap, mode)) {
                is GeminiResult.Success -> {
                    val enhanced = result.enhancedImageBase64?.let {
                        GeminiApiClient.base64ToBitmap(it)
                    } ?: bitmap

                    viewModelScope.launch(Dispatchers.Main) {
                        _enhancedBitmap.value = enhanced
                        _isProcessing.value = false
                    }
                }
                is GeminiResult.Error -> {
                    viewModelScope.launch(Dispatchers.Main) {
                        _errorMessage.value = result.message
                        _isProcessing.value = false
                    }
                }
            }
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }
}

// ══════════════════════════════════════════════════════
//  MAIN ACTIVITY
// ══════════════════════════════════════════════════════

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CameraBlack
                ) {
                    AiCameraApp()
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════
//  ROOT COMPOSABLE WITH PERMISSION HANDLING
// ══════════════════════════════════════════════════════

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun AiCameraApp(viewModel: CameraViewModel = viewModel()) {
    val permissionsState = rememberMultiplePermissionsState(
        permissions = buildList {
            add(Manifest.permission.CAMERA)
            add(Manifest.permission.INTERNET)
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.READ_MEDIA_IMAGES)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
    )

    LaunchedEffect(Unit) {
        permissionsState.launchMultiplePermissionRequest()
    }

    val allGranted = permissionsState.permissions.all { it.status.isGranted }

    if (allGranted) {
        CameraScreen(viewModel = viewModel)
    } else {
        PermissionDeniedScreen {
            permissionsState.launchMultiplePermissionRequest()
        }
    }
}

// ══════════════════════════════════════════════════════
//  PERMISSION DENIED SCREEN
// ══════════════════════════════════════════════════════

@Composable
fun PermissionDeniedScreen(onRetry: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CameraBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "Izin Kamera Diperlukan",
                color = CameraWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Aplikasi memerlukan akses kamera\nuntuk berfungsi.",
                color = CameraGray,
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(CameraYellow)
                    .clickable { onRetry() }
                    .padding(horizontal = 32.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Berikan Izin",
                    color = CameraBlack,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

// ══════════════════════════════════════════════════════
//  CAMERA SCREEN — MAIN FULLSCREEN UI
// ══════════════════════════════════════════════════════

@Composable
fun CameraScreen(viewModel: CameraViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // State
    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var flashMode by remember { mutableStateOf(ImageCapture.FLASH_MODE_AUTO) }
    var isHdrEnabled by remember { mutableStateOf(false) }
    var currentZoomRatio by remember { mutableFloatStateOf(1f) }
    var maxZoomRatio by remember { mutableFloatStateOf(8f) }
    var minZoomRatio by remember { mutableFloatStateOf(0.5f) }
    var cameraInstance by remember { mutableStateOf<Camera?>(null) }
    var galleryUri by remember { mutableStateOf<Uri?>(null) }

    val selectedMode by viewModel.selectedMode.observeAsState(CameraMode.PHOTO)
    val isProcessing by viewModel.isProcessing.observeAsState(false)
    val lastBitmap by viewModel.lastCapturedBitmap.observeAsState(null)

    // Camera executor
    val cameraExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) {
        onDispose { cameraExecutor.shutdown() }
    }

    // PreviewView
    val previewView = remember { PreviewView(context) }

    // ImageCapture use case
    val imageCapture = remember(lensFacing, flashMode) {
        ImageCapture.Builder()
            .setFlashMode(flashMode)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()
    }

    // Gallery picker
    val galleryLauncher = rememberLauncherGallery { uri -> galleryUri = uri }

    // Bind camera when lensFacing changes
    LaunchedEffect(lensFacing, selectedMode) {
        bindCamera(
            context = context,
            lifecycleOwner = lifecycleOwner,
            previewView = previewView,
            imageCapture = imageCapture,
            lensFacing = lensFacing,
            isHdrEnabled = isHdrEnabled,
            onCameraReady = { camera ->
                cameraInstance = camera
                val zoomState: ZoomState? = camera.cameraInfo.zoomState.value
                maxZoomRatio = zoomState?.maxZoomRatio ?: 8f
                minZoomRatio = zoomState?.minZoomRatio ?: 0.5f
            }
        )
    }

    // ──────────────────────────────────────────
    // ROOT FULLSCREEN BOX
    // ──────────────────────────────────────────
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CameraBlack)
            // Pinch-to-Zoom gesture
            .pointerInput(cameraInstance) {
                detectTransformGestures { _, _, zoom, _ ->
                    val camera = cameraInstance ?: return@detectTransformGestures
                    val currentZoom = camera.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                    val newZoom = (currentZoom * zoom).coerceIn(minZoomRatio, maxZoomRatio)
                    camera.cameraControl.setZoomRatio(newZoom)
                    currentZoomRatio = newZoom
                }
            }
    ) {
        // ── LAYER 1: CAMERA PREVIEW ──────────────
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize()
        )

        // ── LAYER 2: TOP BAR ──────────────────────
        TopBarOverlay(
            flashMode = flashMode,
            isHdrEnabled = isHdrEnabled,
            onFlashToggle = {
                flashMode = when (flashMode) {
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                    else -> ImageCapture.FLASH_MODE_AUTO
                }
            },
            onHdrToggle = { isHdrEnabled = !isHdrEnabled },
            onSettingsClick = { /* settings intent */ }
        )

        // ── LAYER 3: BOTTOM CONTROL AREA ─────────
        BottomControlOverlay(
            modifier = Modifier.align(Alignment.BottomCenter),
            selectedMode = selectedMode,
            currentZoomRatio = currentZoomRatio,
            minZoomRatio = minZoomRatio,
            maxZoomRatio = maxZoomRatio,
            isProcessing = isProcessing,
            lastBitmap = lastBitmap,
            galleryUri = galleryUri,
            onModeSelected = { viewModel.setMode(it) },
            onZoomSelected = { ratio ->
                val clampedRatio = ratio.coerceIn(minZoomRatio, maxZoomRatio)
                cameraInstance?.cameraControl?.setZoomRatio(clampedRatio)
                currentZoomRatio = clampedRatio
            },
            onShutterClick = {
                capturePhoto(
                    context = context,
                    imageCapture = imageCapture,
                    executor = cameraExecutor,
                    onCaptured = { bitmap -> viewModel.processImage(bitmap) }
                )
            },
            onSwitchCamera = {
                lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                    CameraSelector.LENS_FACING_FRONT
                else
                    CameraSelector.LENS_FACING_BACK
            },
            onGalleryClick = {
                galleryLauncher.launch("image/*")
            }
        )
    }
}

// ══════════════════════════════════════════════════════
//  TOP BAR OVERLAY
// ══════════════════════════════════════════════════════

@Composable
fun TopBarOverlay(
    flashMode: Int,
    isHdrEnabled: Boolean,
    onFlashToggle: () -> Unit,
    onHdrToggle: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 48.dp, start = 8.dp, end = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Settings
        IconButton(onClick = onSettingsClick) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = CameraWhite,
                modifier = Modifier.size(24.dp)
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Aspect Ratio Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(CameraOverlayDark)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "4:3",
                    color = CameraWhite,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // HDR Toggle
            IconButton(onClick = onHdrToggle) {
                Icon(
                    imageVector = Icons.Default.Hdr,
                    contentDescription = "HDR",
                    tint = if (isHdrEnabled) CameraYellow else CameraWhite,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Flash Toggle
            IconButton(onClick = onFlashToggle) {
                val flashIcon = when (flashMode) {
                    ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                    ImageCapture.FLASH_MODE_OFF -> Icons.Default.FlashOff
                    else -> Icons.Default.FlashAuto
                }
                val flashTint = when (flashMode) {
                    ImageCapture.FLASH_MODE_ON -> CameraYellow
                    else -> CameraWhite
                }
                Icon(
                    imageVector = flashIcon,
                    contentDescription = "Flash",
                    tint = flashTint,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

// ══════════════════════════════════════════════════════
//  BOTTOM CONTROL OVERLAY
// ══════════════════════════════════════════════════════

@Composable
fun BottomControlOverlay(
    modifier: Modifier = Modifier,
    selectedMode: CameraMode,
    currentZoomRatio: Float,
    minZoomRatio: Float,
    maxZoomRatio: Float,
    isProcessing: Boolean,
    lastBitmap: Bitmap?,
    galleryUri: Uri?,
    onModeSelected: (CameraMode) -> Unit,
    onZoomSelected: (Float) -> Unit,
    onShutterClick: () -> Unit,
    onSwitchCamera: () -> Unit,
    onGalleryClick: () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color(0xCC000000)),
                    startY = 0f,
                    endY = 400f
                )
            )
            .padding(bottom = 36.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // ── ROW 1: Zoom Selector ─────────────
            ZoomSelectorRow(
                currentZoom = currentZoomRatio,
                minZoom = minZoomRatio,
                maxZoom = maxZoomRatio,
                onZoomSelected = onZoomSelected
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── ROW 2: Mode Carousel ─────────────
            ModeCarousel(
                selectedMode = selectedMode,
                onModeSelected = onModeSelected
            )

            Spacer(modifier = Modifier.height(20.dp))

            // ── ROW 3: Action Buttons ────────────
            ActionButtonRow(
                isProcessing = isProcessing,
                lastBitmap = lastBitmap,
                galleryUri = galleryUri,
                onShutterClick = onShutterClick,
                onSwitchCamera = onSwitchCamera,
                onGalleryClick = onGalleryClick
            )
        }
    }
}

// ══════════════════════════════════════════════════════
//  ZOOM SELECTOR ROW
// ══════════════════════════════════════════════════════

@Composable
fun ZoomSelectorRow(
    currentZoom: Float,
    minZoom: Float,
    maxZoom: Float,
    onZoomSelected: (Float) -> Unit
) {
    val zoomLevels = buildList {
        if (minZoom <= 0.6f) add(Pair("0.5x", 0.5f))
        add(Pair("1x", 1f))
        add(Pair("2x", 2f))
        add(Pair("${maxZoom.toInt()}x", maxZoom))
    }.distinctBy { it.second }

    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        zoomLevels.forEach { (label, ratio) ->
            val isSelected = kotlin.math.abs(currentZoom - ratio) < 0.15f
            ZoomCapsule(
                label = label,
                isSelected = isSelected,
                onClick = { onZoomSelected(ratio) }
            )
        }
    }
}

@Composable
fun ZoomCapsule(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(
                if (isSelected) Color(0xBBFFFFFF) else Color(0x44FFFFFF)
            )
            .border(
                width = if (isSelected) 1.dp else 0.dp,
                color = if (isSelected) CameraWhite else Color.Transparent,
                shape = RoundedCornerShape(50)
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) CameraBlack else CameraWhite,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// ══════════════════════════════════════════════════════
//  MODE CAROUSEL
// ══════════════════════════════════════════════════════

@Composable
fun ModeCarousel(
    selectedMode: CameraMode,
    onModeSelected: (CameraMode) -> Unit
) {
    val modes = CameraMode.values()

    Row(
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        modes.forEach { mode ->
            val isActive = mode == selectedMode
            ModeLabel(
                label = mode.label,
                isActive = isActive,
                onClick = { onModeSelected(mode) }
            )
            if (mode != modes.last()) {
                Spacer(modifier = Modifier.width(20.dp))
            }
        }
    }
}

@Composable
fun ModeLabel(
    label: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    val scale by animateFloatAsState(
        targetValue = if (isActive) 1.1f else 1f,
        animationSpec = tween(durationMillis = 200),
        label = "mode_scale"
    )

    Text(
        text = label,
        color = if (isActive) CameraYellow else Color(0xAAFFFFFF),
        fontSize = if (isActive) 15.sp else 13.sp,
        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier
            .scale(scale)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onClick() }
    )
}

// ══════════════════════════════════════════════════════
//  ACTION BUTTON ROW
// ══════════════════════════════════════════════════════

@Composable
fun ActionButtonRow(
    isProcessing: Boolean,
    lastBitmap: Bitmap?,
    galleryUri: Uri?,
    onShutterClick: () -> Unit,
    onSwitchCamera: () -> Unit,
    onGalleryClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // ── LEFT: Gallery Thumbnail ───────────
        GalleryThumbnail(
            bitmap = lastBitmap,
            galleryUri = galleryUri,
            isProcessing = isProcessing,
            onClick = onGalleryClick
        )

        // ── CENTER: Shutter Button ────────────
        ShutterButton(onClick = onShutterClick)

        // ── RIGHT: Switch Camera ──────────────
        SwitchCameraButton(onClick = onSwitchCamera)
    }
}

// ══════════════════════════════════════════════════════
//  GALLERY THUMBNAIL
// ══════════════════════════════════════════════════════

@Composable
fun GalleryThumbnail(
    bitmap: Bitmap?,
    galleryUri: Uri?,
    isProcessing: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .border(2.dp, CameraWhite, CircleShape)
            .background(Color(0x44FFFFFF))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        when {
            bitmap != null -> {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Last photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            galleryUri != null -> {
                Image(
                    painter = rememberAsyncImagePainter(galleryUri),
                    contentDescription = "Gallery",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            else -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x55FFFFFF))
                )
            }
        }

        // AI Processing Overlay
        AnimatedVisibility(
            visible = isProcessing,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xAA000000)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(32.dp),
                    color = CameraYellow,
                    strokeWidth = 2.5.dp
                )
            }
        }
    }
}

// ══════════════════════════════════════════════════════
//  SHUTTER BUTTON
// ══════════════════════════════════════════════════════

@Composable
fun ShutterButton(onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1f,
        animationSpec = tween(durationMillis = 100),
        label = "shutter_scale"
    )

    Box(
        modifier = Modifier
            .size(78.dp)
            .scale(scale)
            .clip(CircleShape)
            .border(4.dp, CameraWhite, CircleShape)
            .background(Color(0x22FFFFFF))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(CameraWhite)
        )
    }
}

// ══════════════════════════════════════════════════════
//  SWITCH CAMERA BUTTON
// ══════════════════════════════════════════════════════

@Composable
fun SwitchCameraButton(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(Color(0x44FFFFFF))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Cameraswitch,
            contentDescription = "Switch Camera",
            tint = CameraWhite,
            modifier = Modifier.size(28.dp)
        )
    }
}

// ══════════════════════════════════════════════════════
//  CAMERA BINDING — SAMSUNG ULTRAWIDE OPTIMIZATION
// ══════════════════════════════════════════════════════

fun bindCamera(
    context: Context,
    lifecycleOwner: androidx.lifecycle.LifecycleOwner,
    previewView: PreviewView,
    imageCapture: ImageCapture,
    lensFacing: Int,
    isHdrEnabled: Boolean,
    onCameraReady: (Camera) -> Unit
) {
    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
    cameraProviderFuture.addListener({
        val cameraProvider = cameraProviderFuture.get()

        // ── SAMSUNG ULTRAWIDE: find physical camera with shortest focal length ──
        val cameraSelector = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
            findUltrawideCameraSelector(context, cameraProvider) ?: CameraSelector.DEFAULT_BACK_CAMERA
        } else {
            CameraSelector.DEFAULT_FRONT_CAMERA
        }

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }

        try {
            cameraProvider.unbindAll()

            // Try HDR extension if enabled
            if (isHdrEnabled) {
                tryBindWithHdr(
                    context = context,
                    lifecycleOwner = lifecycleOwner,
                    cameraProvider = cameraProvider,
                    cameraSelector = cameraSelector,
                    preview = preview,
                    imageCapture = imageCapture,
                    onCameraReady = onCameraReady,
                    fallback = {
                        val camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner, cameraSelector, preview, imageCapture
                        )
                        onCameraReady(camera)
                    }
                )
            } else {
                val camera = cameraProvider.bindToLifecycle(
                    lifecycleOwner, cameraSelector, preview, imageCapture
                )
                onCameraReady(camera)
            }

        } catch (exc: Exception) {
            Log.e("CameraX", "Use case binding failed", exc)
        }
    }, ContextCompat.getMainExecutor(context))
}

// ══════════════════════════════════════════════════════
//  SAMSUNG PHYSICAL CAMERA SELECTOR (ULTRAWIDE)
// ══════════════════════════════════════════════════════

@androidx.annotation.OptIn(androidx.camera.camera2.interop.ExperimentalCamera2Interop::class)
fun findUltrawideCameraSelector(
    context: Context,
    cameraProvider: ProcessCameraProvider
): CameraSelector? {
    return try {
        // Get all available cameras
        val availableCameraInfos = cameraProvider.availableCameraInfos

        var shortestFocalLength = Float.MAX_VALUE
        var ultrawideCameraId: String? = null

        for (cameraInfo in availableCameraInfos) {
            if (CameraSelector.DEFAULT_BACK_CAMERA.filter(listOf(cameraInfo)).isEmpty()) {
                continue
            }

            val camera2Info = Camera2CameraInfo.from(cameraInfo)
            val cameraId = camera2Info.cameraId

            try {
                val cameraManager = context.getSystemService(Context.CAMERA_SERVICE)
                        as android.hardware.camera2.CameraManager
                val characteristics = cameraManager.getCameraCharacteristics(cameraId)

                val focalLengths = characteristics.get(
                    android.hardware.camera2.CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS
                )

                if (focalLengths != null && focalLengths.isNotEmpty()) {
                    val minFocalLength = focalLengths.minOrNull() ?: Float.MAX_VALUE
                    // Ultrawide typically has focal length < 2mm
                    if (minFocalLength < shortestFocalLength && minFocalLength < 2.5f) {
                        shortestFocalLength = minFocalLength
                        ultrawideCameraId = cameraId
                    }
                }
            } catch (e: Exception) {
                Log.w("CameraX", "Cannot read focal length for camera $cameraId", e)
            }
        }

        if (ultrawideCameraId != null) {
            // Build CameraSelector using Camera2Interop to force physical camera
            val builder = CameraSelector.Builder()
            Camera2Interop.Extender(
                Preview.Builder() // dummy, we just need the interop reference
            )

            // Use CameraSelector with physical camera ID filter
            CameraSelector.Builder()
                .addCameraFilter { cameraInfoList ->
                    cameraInfoList.filter { cameraInfo ->
                        try {
                            val id = Camera2CameraInfo.from(cameraInfo).cameraId
                            id == ultrawideCameraId
                        } catch (e: Exception) {
                            false
                        }
                    }
                }
                .build()
        } else {
            null
        }
    } catch (e: Exception) {
        Log.e("CameraX", "Failed to find ultrawide camera", e)
        null
    }
}

// ══════════════════════════════════════════════════════
//  HDR EXTENSION BINDING
// ══════════════════════════════════════════════════════

fun tryBindWithHdr(
    context: Context,
    lifecycleOwner: androidx.lifecycle.LifecycleOwner,
    cameraProvider: ProcessCameraProvider,
    cameraSelector: CameraSelector,
    preview: Preview,
    imageCapture: ImageCapture,
    onCameraReady: (Camera) -> Unit,
    fallback: () -> Unit
) {
    val extensionsManagerFuture = ExtensionsManager.getInstanceAsync(context, cameraProvider)
    extensionsManagerFuture.addListener({
        val extensionsManager = extensionsManagerFuture.get()
        if (extensionsManager.isExtensionAvailable(cameraSelector, ExtensionMode.HDR)) {
            val hdrCameraSelector = extensionsManager.getExtensionEnabledCameraSelector(
                cameraSelector, ExtensionMode.HDR
            )
            try {
                val camera = cameraProvider.bindToLifecycle(
                    lifecycleOwner, hdrCameraSelector, preview, imageCapture
                )
                onCameraReady(camera)
            } catch (e: Exception) {
                Log.w("CameraX", "HDR binding failed, falling back", e)
                fallback()
            }
        } else {
            fallback()
        }
    }, ContextCompat.getMainExecutor(context))
}

// ══════════════════════════════════════════════════════
//  PHOTO CAPTURE
// ══════════════════════════════════════════════════════

fun capturePhoto(
    context: Context,
    imageCapture: ImageCapture,
    executor: ExecutorService,
    onCaptured: (Bitmap) -> Unit
) {
    val name = "AiCamera_${System.currentTimeMillis()}.jpg"
    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AiCamera")
        }
    }

    val outputOptions = ImageCapture.OutputFileOptions.Builder(
        context.contentResolver,
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
        contentValues
    ).build()

    imageCapture.takePicture(
        outputOptions,
        executor,
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                val savedUri = output.savedUri ?: return
                try {
                    val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        val source = android.graphics.ImageDecoder.createSource(
                            context.contentResolver, savedUri
                        )
                        android.graphics.ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                            decoder.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        MediaStore.Images.Media.getBitmap(context.contentResolver, savedUri)
                    }
                    onCaptured(bitmap)
                } catch (e: Exception) {
                    Log.e("CameraX", "Failed to decode bitmap", e)
                }
            }

            override fun onError(exception: ImageCaptureException) {
                Log.e("CameraX", "Photo capture failed: ${exception.message}", exception)
            }
        }
    )
}

// ══════════════════════════════════════════════════════
//  GALLERY LAUNCHER HELPER
// ══════════════════════════════════════════════════════

@Composable
fun rememberLauncherGallery(
    onResult: (Uri?) -> Unit
): androidx.activity.result.ActivityResultLauncher<String> {
    val context = LocalContext.current
    return androidx.activity.compose.rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri ->
            if (uri != null) {
                // Also open system gallery
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "image/*")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                try {
                    context.startActivity(intent)
                } catch (e: Exception) {
                    Log.w("Gallery", "No gallery app found", e)
                }
                onResult(uri)
            }
        }
    )
}
