package com.example.aicamera

import android.graphics.Bitmap
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

// ──────────────────────────────────────────────
// DATA MODELS — REQUEST
// ──────────────────────────────────────────────

data class GeminiRequest(
    @SerializedName("contents") val contents: List<Content>
)

data class Content(
    @SerializedName("parts") val parts: List<Part>
)

data class Part(
    @SerializedName("text") val text: String? = null,
    @SerializedName("inline_data") val inlineData: InlineData? = null
)

data class InlineData(
    @SerializedName("mime_type") val mimeType: String,
    @SerializedName("data") val data: String
)

// ──────────────────────────────────────────────
// DATA MODELS — RESPONSE
// ──────────────────────────────────────────────

data class GeminiResponse(
    @SerializedName("candidates") val candidates: List<Candidate>?,
    @SerializedName("error") val error: GeminiError?
)

data class Candidate(
    @SerializedName("content") val content: ContentResponse?,
    @SerializedName("finishReason") val finishReason: String?
)

data class ContentResponse(
    @SerializedName("parts") val parts: List<PartResponse>?,
    @SerializedName("role") val role: String?
)

data class PartResponse(
    @SerializedName("text") val text: String?,
    @SerializedName("inline_data") val inlineData: InlineDataResponse?
)

data class InlineDataResponse(
    @SerializedName("mime_type") val mimeType: String?,
    @SerializedName("data") val data: String?
)

data class GeminiError(
    @SerializedName("code") val code: Int?,
    @SerializedName("message") val message: String?,
    @SerializedName("status") val status: String?
)

// ──────────────────────────────────────────────
// RETROFIT SERVICE INTERFACE
// ──────────────────────────────────────────────

interface GeminiApiService {
    @Headers("Content-Type: application/json")
    @POST("v1beta/models/gemini-2.0-flash:generateContent")
    suspend fun generateContent(
        @Body request: GeminiRequest,
        @Query("key") apiKey: String
    ): Response<GeminiResponse>
}

// ──────────────────────────────────────────────
// CAMERA MODE ENUM
// ──────────────────────────────────────────────

enum class CameraMode(val label: String) {
    PRO("PRO"),
    VIDEO("VIDEO"),
    PHOTO("PHOTO"),
    PORTRAIT("PORTRAIT")
}

// ──────────────────────────────────────────────
// SEALED RESULT CLASS
// ──────────────────────────────────────────────

sealed class GeminiResult {
    data class Success(
        val enhancedImageBase64: String?,
        val description: String
    ) : GeminiResult()

    data class Error(val message: String) : GeminiResult()
}

// ──────────────────────────────────────────────
// GEMINI API CLIENT
// ──────────────────────────────────────────────

object GeminiApiClient {

    private const val API_KEY = "AIzaSyAIdnUkx-fLhGtrcliG7Inc3ju_22dJi0U"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val service: GeminiApiService = retrofit.create(GeminiApiService::class.java)

    // ──────────────────────────────────────────
    // PROMPT BUILDER PER MODE
    // ──────────────────────────────────────────

    private fun buildPromptForMode(mode: CameraMode): String {
        return when (mode) {
            CameraMode.PHOTO ->
                "Tingkatkan resolusi gambar menjadi Ultra HD, hilangkan noise, " +
                "optimalkan HDR, dan pertajam detail mikro. Kembalikan gambar yang sudah " +
                "ditingkatkan kualitasnya dalam format Base64 JPEG."

            CameraMode.PORTRAIT ->
                "Terapkan efek bokeh/blur latar belakang sekelas DSLR f/1.4, dan pertajam " +
                "ketajaman khusus pada subjek utama. Pisahkan subjek dari latar belakang " +
                "dengan presisi tinggi dan kembalikan hasil dalam format Base64 JPEG."

            CameraMode.PRO ->
                "Terapkan Cinematic Color Grading, tingkatkan micro-contrast tanpa merusak " +
                "pencahayaan manual aslinya. Berikan nuansa sinematik profesional dan " +
                "kembalikan gambar hasil grading dalam format Base64 JPEG."

            CameraMode.VIDEO ->
                "Analisis frame ini dari video, optimalkan eksposur dan warna untuk kualitas " +
                "video sinematik, kembalikan frame yang ditingkatkan dalam format Base64 JPEG."
        }
    }

    // ──────────────────────────────────────────
    // BITMAP → BASE64
    // ──────────────────────────────────────────

    fun bitmapToBase64(bitmap: Bitmap, quality: Int = 90): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    // ──────────────────────────────────────────
    // MAIN ENHANCE FUNCTION — RUNS ON IO THREAD
    // ──────────────────────────────────────────

    suspend fun enhanceImage(
        bitmap: Bitmap,
        mode: CameraMode
    ): GeminiResult = withContext(Dispatchers.IO) {
        try {
            val base64Image = bitmapToBase64(bitmap)
            val prompt = buildPromptForMode(mode)

            val request = GeminiRequest(
                contents = listOf(
                    Content(
                        parts = listOf(
                            Part(
                                inlineData = InlineData(
                                    mimeType = "image/jpeg",
                                    data = base64Image
                                )
                            ),
                            Part(text = prompt)
                        )
                    )
                )
            )

            val response = service.generateContent(
                request = request,
                apiKey = API_KEY
            )

            if (response.isSuccessful) {
                val body = response.body()

                // Check for API-level error in body
                if (body?.error != null) {
                    return@withContext GeminiResult.Error(
                        "API Error ${body.error.code}: ${body.error.message}"
                    )
                }

                val candidates = body?.candidates
                if (candidates.isNullOrEmpty()) {
                    return@withContext GeminiResult.Error("Tidak ada hasil dari Gemini API.")
                }

                val firstCandidate = candidates[0]
                val parts = firstCandidate.content?.parts

                // Try to extract enhanced image base64 from response
                var enhancedBase64: String? = null
                var descriptionText = "Peningkatan gambar berhasil dilakukan."

                parts?.forEach { part ->
                    when {
                        part.inlineData != null -> {
                            enhancedBase64 = part.inlineData.data
                        }
                        part.text != null -> {
                            descriptionText = part.text
                        }
                    }
                }

                GeminiResult.Success(
                    enhancedImageBase64 = enhancedBase64,
                    description = descriptionText
                )

            } else {
                val errorBody = response.errorBody()?.string()
                val errorMessage = try {
                    val errorResponse = Gson().fromJson(errorBody, GeminiResponse::class.java)
                    errorResponse.error?.message ?: "HTTP ${response.code()}: ${response.message()}"
                } catch (e: Exception) {
                    "HTTP ${response.code()}: ${response.message()}"
                }
                GeminiResult.Error(errorMessage)
            }

        } catch (e: Exception) {
            GeminiResult.Error("Koneksi gagal: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    // ──────────────────────────────────────────
    // BASE64 → BITMAP
    // ──────────────────────────────────────────

    fun base64ToBitmap(base64String: String): Bitmap? {
        return try {
            val decodedBytes = Base64.decode(base64String, Base64.NO_WRAP)
            android.graphics.BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
        } catch (e: Exception) {
            null
        }
    }
}
